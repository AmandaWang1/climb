#ifndef _SYSTICK_H
#define _SYSTICK_H

#include "stm32f10x.h"
#include "core_cm3.h"

void delay_us(uint32_t us);
void delay_ms(uint32_t ms);


#endif /*_SYSTICK_H*/


